<?php

if(function_exists('premmerce_wsa_fs')){
	premmerce_wsa_fs()->_contact_page_render();
}
